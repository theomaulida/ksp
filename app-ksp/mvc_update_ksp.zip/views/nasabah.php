<style type="text/css" media="print">
@media print {
    .noprint {display:none !important;}
    a:link:after, a:visited:after {  
      display: none;
      content: "";    
    }
}
</style>
<div class="container-fluid fixed">
	<div id="content">
<div class="separator"></div>

<div class="widget widget-4 widget-body-white">

	<div class="widget-head hidden-print">
		<h4 class="heading">Data Anggota  | <?php echo anchor('main/nasabah/add','Tambah Anggota')?> | <?php //echo anchor('main/exportxls','Export ke Excel')?></h4>
	</div>
	<div class="widget-body" style="padding: 10px 0 0;">
		<table class="dynamicTable table table-striped table-bordered table-primary table-condensed">
			<thead>
				<tr>
					<th>NO</th>
					<th>NO PEGAWAI</th>
					<th>NAMA_ANGGOTA</th>
					<th>DEPARTEMEN</th>
					<th>TGL MASUK</th>
					<th class="hidden-print" width="12%">ACTION</th>
					<th class="hidden-print" width="27%">SIMPAN/PINJAM </th>
				</tr>
			</thead>
			<tbody>	
			</tbody>
		</table>
	</div>
</div>
