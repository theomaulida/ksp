<div class="container-fluid fixed">
		
				
		<div id="content">

			<div id="login"><h3>Login Tabungan Sekolah</h3>
	<form class="form-signin" method="post" action="login" />
		<label class="strong">Username</label>
		<input type="text" class="input-block-level" name="username" placeholder="Username" required autofocus/>
		<label class="strong">Password</label> 
		<input type="password" class="input-block-level" name="password" placeholder="Password" required/>
		
		<div class="separator line"></div> 
		<button class="btn btn-large btn-primary pull-right" type="submit">MASUK</button>
		<div class="clearfix"></div>
	</form></div></div>